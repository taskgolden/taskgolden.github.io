FC，150合一精品集，献给70,80,90,的六一回忆。附下载链
https://www.bilibili.com/video/BV1FA4y1f7R3/

吵饭王
置顶 链接：https://pan.baidu.com/s/1yzBOo6DHvXR1EqbAIuQbnQ
提取码：3366

150合一附模拟器——B站吵饭王.rar
口袋里的游戏 150合1 .nes


> CertUtil -hashfile '.\150-in-1.nes' md5
MD5 的 .\150-in-1.nes 哈希:
4e559bba845e194465f7a5836523402c
CertUtil: -hashfile 命令成功完成。
>