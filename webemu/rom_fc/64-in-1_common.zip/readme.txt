https://nesninja.com/game/nes/multi-game-pirate-carts?rom=64-in-1%20%5Ba1%5D%5Bp1%5D.nes

> CertUtil -hashfile '.\64-in-1 [a1][p1].nes' md5
MD5 的 .\64-in-1 [a1][p1].nes 哈希:
fb88b6885081c147be8f1402861ff70f
CertUtil: -hashfile 命令成功完成。
>

最常见的64合1，53个不重复游戏