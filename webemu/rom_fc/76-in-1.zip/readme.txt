https://nesninja.com/game/nes/multi-game-pirate-carts?rom=76-in-1%20%5Bp1%5D%5B%21%5D.nes

> CertUtil -hashfile '.\76-in-1 [p1][!].nes' md5
MD5 的 .\76-in-1 [p1][!].nes 哈希:
07cd0643dfce31537b9c8a1de67d0e6f
CertUtil: -hashfile 命令成功完成。
>